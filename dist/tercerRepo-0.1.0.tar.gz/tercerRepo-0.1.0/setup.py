from setuptools import setup, find_packages

setup(
    name="tercerRepo",                                   # Nombre del paquete
    version="0.1.0",                                     # Versión inicial
    packages=find_packages(),                            # Paquetes a incluir
    description="Un paquete pip simple de saludo",       # Breve descripción
    author="Gerson Cano Meneses",                        # Tu nombre
    author_email="gerson.cano210@pascualbravo.edu.co",   # Tu correo electrónico
    url="https://github.com/gersoncano210/tercerrepo",   # URL del proyecto
)